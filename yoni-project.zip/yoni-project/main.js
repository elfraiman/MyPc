(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _installation_guide_installation_guide_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./installation-guide/installation-guide.component */ "./src/app/installation-guide/installation-guide.component.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _navigation_navigation_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./navigation/navigation.component */ "./src/app/navigation/navigation.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _signup_signup_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./signup/signup.component */ "./src/app/signup/signup.component.ts");
/* harmony import */ var _homepage_header_main_header_main_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./homepage/header-main/header-main.component */ "./src/app/homepage/header-main/header-main.component.ts");
/* harmony import */ var _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./homepage/homepage.component */ "./src/app/homepage/homepage.component.ts");
/* harmony import */ var _homepage_footer_main_footer_main_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./homepage/footer-main/footer-main.component */ "./src/app/homepage/footer-main/footer-main.component.ts");
/* harmony import */ var _homepage_body_main_body_main_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./homepage/body-main/body-main.component */ "./src/app/homepage/body-main/body-main.component.ts");
/* harmony import */ var _directives_border_nav_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./directives/border-nav.directive */ "./src/app/directives/border-nav.directive.ts");
/* harmony import */ var angularfire2__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! angularfire2 */ "./node_modules/angularfire2/index.js");
/* harmony import */ var angularfire2_database__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! angularfire2/database */ "./node_modules/angularfire2/database/index.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! angularfire2/auth */ "./node_modules/angularfire2/auth/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ng2-animate-on-scroll */ "./node_modules/ng2-animate-on-scroll/dist/index.js");
/* harmony import */ var ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_22__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};























var routes = [
    {
        path: 'login',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"]
    },
    {
        path: 'signup',
        component: _signup_signup_component__WEBPACK_IMPORTED_MODULE_10__["SignupComponent"]
    },
    {
        path: '',
        component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_12__["HomepageComponent"]
    },
    {
        path: 'home',
        component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_12__["HomepageComponent"]
    },
    {
        path: 'installation',
        component: _installation_guide_installation_guide_component__WEBPACK_IMPORTED_MODULE_0__["InstallationGuideComponent"]
    }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
                _navigation_navigation_component__WEBPACK_IMPORTED_MODULE_8__["NavigationComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"],
                _signup_signup_component__WEBPACK_IMPORTED_MODULE_10__["SignupComponent"],
                _homepage_header_main_header_main_component__WEBPACK_IMPORTED_MODULE_11__["HeaderMainComponent"],
                _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_12__["HomepageComponent"],
                _homepage_footer_main_footer_main_component__WEBPACK_IMPORTED_MODULE_13__["FooterMainComponent"],
                _homepage_body_main_body_main_component__WEBPACK_IMPORTED_MODULE_14__["BodyMainComponent"],
                _directives_border_nav_directive__WEBPACK_IMPORTED_MODULE_15__["BorderNavDirective"],
                _installation_guide_installation_guide_component__WEBPACK_IMPORTED_MODULE_0__["InstallationGuideComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatOptionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatAutocompleteModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatBadgeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatBottomSheetModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatButtonToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatChipsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDatepickerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDialogModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDividerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatGridListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatNativeDateModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatProgressBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatProgressSpinnerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatRippleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSliderModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSlideToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSnackBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatStepperModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTabsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTooltipModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTreeModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(routes),
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
                angularfire2__WEBPACK_IMPORTED_MODULE_16__["AngularFireModule"].initializeApp(_environments_environment__WEBPACK_IMPORTED_MODULE_19__["environment"].firebase),
                angularfire2_database__WEBPACK_IMPORTED_MODULE_17__["AngularFireDatabaseModule"],
                angularfire2_auth__WEBPACK_IMPORTED_MODULE_18__["AngularFireAuthModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__["NgbModule"].forRoot(),
                ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_22__["AnimateOnScrollModule"].forRoot()
            ],
            providers: [_services_auth_service__WEBPACK_IMPORTED_MODULE_21__["AuthService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/directives/border-nav.directive.ts":
/*!****************************************************!*\
  !*** ./src/app/directives/border-nav.directive.ts ***!
  \****************************************************/
/*! exports provided: BorderNavDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BorderNavDirective", function() { return BorderNavDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var BorderNavDirective = /** @class */ (function () {
    // Renderer2 reminds me of jQuery, look up the documents !important
    function BorderNavDirective(elRef, renderer) {
        this.elRef = elRef;
        this.renderer = renderer;
        this.borderBottom = '1px solid transparent';
    }
    BorderNavDirective.prototype.ngOnInit = function () {
    };
    // HostListener decorator listens to any event
    BorderNavDirective.prototype.onscroll = function (eventData) {
        this.borderBottom = '0.5px solid black';
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"])('style.borderBottom'),
        __metadata("design:type", String)
    ], BorderNavDirective.prototype, "borderBottom", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseenter'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Event]),
        __metadata("design:returntype", void 0)
    ], BorderNavDirective.prototype, "onscroll", null);
    BorderNavDirective = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
            selector: '[appBorderNav]'
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]])
    ], BorderNavDirective);
    return BorderNavDirective;
}());



/***/ }),

/***/ "./src/app/homepage/body-main/body-main.component.css":
/*!************************************************************!*\
  !*** ./src/app/homepage/body-main/body-main.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-content {\n  display: -ms-grid;\n  display: grid;\n  -ms-grid-rows: (1fr)[4];\n  -ms-grid-columns: 15% auto 15%;\n      grid-template: repeat(4, 1fr) / 15% auto 15%;\n  height: 4000px;\n  width: 100%;\n  font-family: 'Montserrat', sans-serif;\n  background-color: rgb(36, 36, 36);\n  color: white;\n}\n\nh2 {\n  -ms-grid-row: 1;\n  -ms-grid-row-span: 1;\n  grid-row: 1/2;\n  text-align: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n  font-size: 100px;\n}\n\n.windows {\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  -ms-grid-row-align: center;\n      align-self: center;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  justify-items: center;\n}\n\n#second-title {\n  -ms-grid-row: 2;\n  -ms-grid-row-span: 1;\n  grid-row: 2/3;\n  -ms-grid-row-align: center;\n      align-self: center;\n  -ms-grid-column-align: start;\n      justify-self: start;\n  text-align: center;\n  font-size: 50px;\n\n}\n\n.animated {\n  visibility: visible !important;\n}\n\n.hide-on-init {\n  visibility: hidden;\n}\n\nbutton {\n  background-color: rgb(255, 255, 255);\n  color: rgb(0, 0, 0);\n  border: none;\n  font-weight: 800;\n  font-size: 13px;\n  padding: 10px 10px;\n  width: 150px;\n  height: 40px;\n  position: absolute;\n  right: 50%;\n  transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -webkit-transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -moz-transition: background-color 0.8s, border 1.0s, color 0.4s;\n}\n\nbutton:hover {\n  cursor: pointer;\n background-color: inherit;\n  border: 2px solid #d500f9;\n  color: #d500f9;\n}\n"

/***/ }),

/***/ "./src/app/homepage/body-main/body-main.component.html":
/*!*************************************************************!*\
  !*** ./src/app/homepage/body-main/body-main.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main-content\">\n  <div animateOnScroll animationName=\"animated fadeInUpBig\" class=\"windows hide-on-init\">\n    <h2> Windows on the go </h2>\n  </div>\n\n  <div animateOnScroll animationName=\"animated zoomInDown\" class=\"windows hide-on-init\">\n    <span id=\"second-title\"> PLUG IN MYPC TO ANY COMPUTER AND BOOT YOUR WINDOWS</span>\n    <hr>\n    <button routerLink=\"installation\">Installation Guide</button>\n  </div>\n\n\n  <div animateOnScroll animationName=\"animated zoomInDown\" class=\"windows hide-on-init\">\n    <span id=\"second-title\"> YONI YOU NEED TO GIVE ME SOME TEXT HERE</span>\n  </div>\n\n\n  <div animateOnScroll animationName=\"animated zoomInDown\" class=\"windows hide-on-init\">\n    <span id=\"second-title\"> PLACE HOLDER TEXT JUST TO SHOW ANIMATION, I NEED MORE TEXT</span>\n  </div>\n\n\n</div>\n"

/***/ }),

/***/ "./src/app/homepage/body-main/body-main.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/homepage/body-main/body-main.component.ts ***!
  \***********************************************************/
/*! exports provided: BodyMainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BodyMainComponent", function() { return BodyMainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var BodyMainComponent = /** @class */ (function () {
    function BodyMainComponent() {
    }
    BodyMainComponent.prototype.ngOnInit = function () {
    };
    BodyMainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-body-main',
            template: __webpack_require__(/*! ./body-main.component.html */ "./src/app/homepage/body-main/body-main.component.html"),
            styles: [__webpack_require__(/*! ./body-main.component.css */ "./src/app/homepage/body-main/body-main.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], BodyMainComponent);
    return BodyMainComponent;
}());



/***/ }),

/***/ "./src/app/homepage/footer-main/footer-main.component.css":
/*!****************************************************************!*\
  !*** ./src/app/homepage/footer-main/footer-main.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-content {\n  font-family: 'Montserrat', sans-serif;\n  background-color: #363636;\n  display: -ms-grid;\n  display: grid;\n  -ms-grid-rows: 1fr;\n  -ms-grid-columns: 1fr 1fr 1fr;\n      grid-template: 1fr / 1fr 1fr 1fr;\n  height: 170px;\n  position: absolute;\n  width: 100%;\n}\n\n.left-box {\n  -ms-grid-column: 1;\n  -ms-grid-column-span: 1;\n  grid-column: 1/2;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n  padding: 10px 10px;\n  position: absolute;\n}\n\n.footer-title {\n  text-align: center;\n  font-size: 25px;\n  font-weight: 700;\n  color: white;\n}\n\n#middle-box {\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n  padding: 10px 15px;\n}\n\n#middle-list {\n  list-style: none;\n  color: white;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n  padding: 10px 10px;\n  font-size: 15px;\n  text-align: center;\n}\n\n#middle-list li {\n  transition: padding-bottom 0.5s, font-size 0.5s;\n}\n\n#middle-list li:hover {\n  font-size: 28px;\n  cursor: pointer;\n  font-weight: 700;\n}\n\n#right-box {\n  color: white;\n  -ms-grid-row-align: center;\n      align-self: center;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  padding: 10px 15px;\n}\n\nmat-divider {\n  background-color: white;\n}\n"

/***/ }),

/***/ "./src/app/homepage/footer-main/footer-main.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/homepage/footer-main/footer-main.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main-content\">\n  <div class=\"left-box\">\n    <span class=\"footer-title\">\n      MyPc<span style=\"color: rgb(233, 214, 48)\">.</span><br>\n    </span>\n  </div>\n  <div id=\"middle-box\">\n    <ul id=\"middle-list\">\n      <li>GET STARTED</li>\n      <li>OUR STORY</li>\n      <li>CONTACT</li>\n      <li>FAQ</li>\n    </ul>\n  </div>\n  <div id=\"right-box\">\n    <p>Copyright @ MyPc 2018</p>\n  </div>\n  <mat-divider [vertical]=\"true\"></mat-divider>\n</div>\n"

/***/ }),

/***/ "./src/app/homepage/footer-main/footer-main.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/homepage/footer-main/footer-main.component.ts ***!
  \***************************************************************/
/*! exports provided: FooterMainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterMainComponent", function() { return FooterMainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterMainComponent = /** @class */ (function () {
    function FooterMainComponent() {
    }
    FooterMainComponent.prototype.ngOnInit = function () {
    };
    FooterMainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer-main',
            template: __webpack_require__(/*! ./footer-main.component.html */ "./src/app/homepage/footer-main/footer-main.component.html"),
            styles: [__webpack_require__(/*! ./footer-main.component.css */ "./src/app/homepage/footer-main/footer-main.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterMainComponent);
    return FooterMainComponent;
}());



/***/ }),

/***/ "./src/app/homepage/header-main/header-main.component.css":
/*!****************************************************************!*\
  !*** ./src/app/homepage/header-main/header-main.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-content {\n  display: -ms-grid;\n  display: grid;\n  -ms-grid-columns: 150px auto 150px;\n      grid-template-columns: 150px auto 150px;\n  height: 850px;\n  width: 100%;\n  margin-top: 5%;\n}\n\n\n#DONT-LOSE-IT {\n  -ms-grid-row: 1;\n  -ms-grid-row-span: 1;\n  grid-row: 1/2;\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n  text-align: center;\n  font-size: 135px;\n  font-weight: 800;\n  z-index: 1;\n  padding: 0px 200px;\n}\n\n\n#paragraph {\n  -ms-grid-row: 2;\n  -ms-grid-row-span: 1;\n  grid-row: 2/3;\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  font-size: 20px;\n  text-align: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n  -ms-grid-column-align: center;\n      justify-self: center;\n}\n\n\n#start-now {\n  background-color: rgb(36, 36, 36);\n  color: white;\n  border: none;\n  font-weight: 800;\n  font-size: 13px;\n  padding: 10px 10px;\n  width: 150px;\n  height: 40px;\n transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -webkit-transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -moz-transition: background-color 0.8s, border 1.0s, color 0.4s;\n}\n\n\n#start-now:hover {\n  cursor: pointer;\n background-color: inherit;\n  border: 2px solid rgb(36, 36, 36);\n  color: rgb(36, 36, 36);\n}\n\n\n@media all and (max-width: 700px) {\n  .main-content,\n  #paragraph {\n    -ms-grid-column: 1;\n    -ms-grid-column-span: 3;\n    grid-column: 1 / 4;\n  }\n}\n"

/***/ }),

/***/ "./src/app/homepage/header-main/header-main.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/homepage/header-main/header-main.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"main-content\">\n    <h2 id=\"DONT-LOSE-IT\">MYPC<span style=\"color: rgb(191, 32, 219)\">.</span> YOUR PC, EVERYWHERE</h2>\n    <span id=\"paragraph\">\n      <p>Keep your data safe before it's too late. Take action today with our automated system and affordable approach.</p>\n        <button id=\"start-now\" routerLink=\"signup\">Start now</button>\n    </span>\n</div>\n\n"

/***/ }),

/***/ "./src/app/homepage/header-main/header-main.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/homepage/header-main/header-main.component.ts ***!
  \***************************************************************/
/*! exports provided: HeaderMainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderMainComponent", function() { return HeaderMainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HeaderMainComponent = /** @class */ (function () {
    function HeaderMainComponent() {
    }
    HeaderMainComponent.prototype.ngOnInit = function () {
    };
    HeaderMainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-header-main',
            template: __webpack_require__(/*! ./header-main.component.html */ "./src/app/homepage/header-main/header-main.component.html"),
            styles: [__webpack_require__(/*! ./header-main.component.css */ "./src/app/homepage/header-main/header-main.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], HeaderMainComponent);
    return HeaderMainComponent;
}());



/***/ }),

/***/ "./src/app/homepage/homepage.component.css":
/*!*************************************************!*\
  !*** ./src/app/homepage/homepage.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/homepage/homepage.component.html":
/*!**************************************************!*\
  !*** ./src/app/homepage/homepage.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-navigation></app-navigation>\n<app-header-main></app-header-main>\n<app-body-main></app-body-main>\n<app-footer-main></app-footer-main>\n"

/***/ }),

/***/ "./src/app/homepage/homepage.component.ts":
/*!************************************************!*\
  !*** ./src/app/homepage/homepage.component.ts ***!
  \************************************************/
/*! exports provided: HomepageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomepageComponent", function() { return HomepageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HomepageComponent = /** @class */ (function () {
    function HomepageComponent() {
    }
    HomepageComponent.prototype.ngOnInit = function () {
    };
    HomepageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-homepage',
            template: __webpack_require__(/*! ./homepage.component.html */ "./src/app/homepage/homepage.component.html"),
            styles: [__webpack_require__(/*! ./homepage.component.css */ "./src/app/homepage/homepage.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], HomepageComponent);
    return HomepageComponent;
}());



/***/ }),

/***/ "./src/app/installation-guide/installation-guide.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/installation-guide/installation-guide.component.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "app-navigation {\n  display: block;\n  position:relative;\n  height: 80px;\n}\n\n.main-content {\n  display: -ms-grid;\n  display: grid;\n  -ms-grid-columns: 15% auto 15%;\n      grid-template-columns: 15% auto 15%;\n  -ms-grid-rows: (auto)[4];\n      grid-template-rows: repeat(4, auto);\n  align-items: center;\n}\n\n.title {\n  font-size: 40px;\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  -ms-grid-row: 1;\n  -ms-grid-row-span: 1;\n  grid-row: 1/2;\n  margin-top: 8%;\n  text-align: center;\n}\n\n.main-body {\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  -ms-grid-row: 2;\n  -ms-grid-row-span: 1;\n  grid-row: 2/3;\n  padding: 50px 0px;\n}\n\n.boot-picture {\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  -ms-grid-row: 3;\n  -ms-grid-row-span: 1;\n  grid-row: 3/4;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  align-items: center;\n  padding-bottom: 50px;\n}\n\n.under-picture-text {\n  -ms-grid-row: 4;\n  -ms-grid-row-span: 1;\n  grid-row: 4/5;\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n}\n\n.bios-pictures {\n  -ms-grid-row: 5;\n  -ms-grid-row-span: 1;\n  grid-row: 5/6;\n  -ms-grid-column: 2;\n  -ms-grid-column-span: 1;\n  grid-column: 2/3;\n  padding: 20px 20px;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  -ms-grid-row-align: center;\n      align-self: center;\n}\n\n.animated {\n  visibility: visible !important;\n}\n\n.hide-on-init {\n  visibility: hidden;\n}\n"

/***/ }),

/***/ "./src/app/installation-guide/installation-guide.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/installation-guide/installation-guide.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-navigation></app-navigation>\n\n\n<div class=\"main-content\">\n  <div animateOnScroll animationName=\"animated zoomInDown\" class=\"title hide-on-init\">\n    <h2> How to boot your MyPc device</h2>\n    <hr>\n  </div>\n\n\n  <div animateOnScroll animationName=\"animated fadeInUpBig\" class=\"main-body hide-on-init\">\n    <span style=\"font-weight: 800\">Step 1. How to boot your MyPc device.</span>\n    <br> This step you will be using when moving between different computers!\n    <br> So the first thing is how to get to the “boot menu”.\n    <br> Using boot menu is very easy anyone can do this you will need an assign keyboard key to press which will open the boot\n    menu when the computer starts.\n    <br> Normally the first boot screen give you the instruction like a key name to open it or you can try some default keys\n    to open it. If the boot screen didn’t show you something then you can try these key one by one to open the boot menu.\n    The keys are Esc, F7, F8, F9, F10, F11 and F12 you can try these keys one at a time by pressing it again and again after\n    the 2 sec of your system starts and if the key is correct your boot menu will open.\n    <br> Try the F10, 11, 12 first because it will assign most for the menu. Sometimes the Esc key take you to the menu where\n    use can select the item what you want to open like bios, boot menu, memory test etc. I means you can try that one too\n    if your computer has that one.\n  </div>\n\n  <div animateOnScroll animationName=\"animated fadeInUpBig\" class=\"boot-picture hide-on-init\">\n    <img style=\"padding: 10px 10px\" src=\"../../assets/bootwindow.png\">\n    <img src=\"../../assets//boot-menu-keys-tablet.png\">\n  </div>\n\n  <div animateOnScroll animationName=\"animated fadeInUpBig\" class=\"under-picture-text hide-on-init\">\n    <p>\n      By using the above keys now I think you are in the boot menu. In this menu now you are seeing all of your Hard Drive, Cd\n      or DVD Drives and USB Device. Now you can easily select the drive what you want to boot from and make it work. Now\n      you want to boot from your USB, you can do it by just selecting the drive USB or USB HDD. Just select the item by your\n      keyboard’s aero key and hit enter that’s it.\n    </p>\n  </div>\n  <div animateOnScroll animationName=\"animated fadeInUpBig\" class=\"bios-pictures hide-on-init\">\n    <img style=\"padding: 10px 10px\" src=\"../../assets/image3.png\">\n\n    <img src=\"../../assets/image4.png\">\n  </div>\n</div>\n\n<app-footer-main></app-footer-main>\n"

/***/ }),

/***/ "./src/app/installation-guide/installation-guide.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/installation-guide/installation-guide.component.ts ***!
  \********************************************************************/
/*! exports provided: InstallationGuideComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InstallationGuideComponent", function() { return InstallationGuideComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var InstallationGuideComponent = /** @class */ (function () {
    function InstallationGuideComponent() {
    }
    InstallationGuideComponent.prototype.ngOnInit = function () {
    };
    InstallationGuideComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-installation-guide',
            template: __webpack_require__(/*! ./installation-guide.component.html */ "./src/app/installation-guide/installation-guide.component.html"),
            styles: [__webpack_require__(/*! ./installation-guide.component.css */ "./src/app/installation-guide/installation-guide.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], InstallationGuideComponent);
    return InstallationGuideComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-content {\n  display: -ms-grid;\n  display: grid;\n  -ms-grid-rows: auto;\n  -ms-grid-columns: auto;\n      grid-template: auto/auto;\n  margin-top: 10%;\n}\n\nh3 {\n  -ms-grid-row: 1;\n  -ms-grid-row-span: 1;\n  grid-row: 1/2;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  font-size: 16px;\n}\n\n.email {\n  -ms-grid-row: 2;\n  -ms-grid-row-span: 1;\n  grid-row: 2/3;\n  -ms-grid-column-align: center;\n      justify-self: center;\n}\n\n.password {\n  -ms-grid-row: 4;\n  -ms-grid-row-span: 1;\n  grid-row: 4/5;\n  -ms-grid-column-align: center;\n      justify-self: center;\n}\n\n#login-btn {\n  -ms-grid-row: 5;\n  -ms-grid-row-span: 1;\n  grid-row: 5/6;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  background-color: rgb(36, 36, 36);\n  color: white;\n  border: none;\n  font-weight: 800;\n  font-size: 13px;\n  padding: 8px 8px;\n  width: 120px;\n  height: 40px;\n  transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -webkit-transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -moz-transition: background-color 0.8s, border 1.0s, color 0.4s;\n}\n\nbutton:hover {\n  cursor: pointer;\n  background-color: white;\n  border: 2px solid rgb(36, 36, 36);\n  color: rgb(36, 36, 36);\n}\n\n#google-btn {\n  -ms-grid-row: 6;\n  -ms-grid-row-span: 1;\n  grid-row: 6/7;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  background-color: rgb(81, 192, 243);\n  color: white;\n  border: none;\n  font-weight: 800;\n  font-size: 13px;\n  padding: 8px 8px;\n  width: 150px;\n  height: 40px;\n  margin-top: 20px;\n  transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -webkit-transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -moz-transition: background-color 0.8s, border 1.0s, color 0.4s;\n}\n"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-navigation class=\"nav\"></app-navigation>\n<div class=\"main-content\">\n  <h3>Please log-in</h3>\n  <p class=\"email\">\n      <mat-form-field appearance=\"outline\">\n          <mat-label>Email</mat-label>\n          <input matInput placeholder=\"Enter your email\" [formControl]=\"email\" required>\n          <mat-error *ngIf=\"email.invalid\">{{getErrorMessage()}}</mat-error>\n          <mat-icon matSuffix>sentiment_very_satisfied</mat-icon>\n        </mat-form-field>\n  </p>\n  <p class=\"password\">\n      <mat-form-field appearance=\"outline\">\n          <mat-label>Password</mat-label>\n          <input matInput placeholder=\"Enter your password\" [type]=\"hide ? 'password' : 'text'\">\n          <mat-icon matSuffix (click)=\"hide = !hide\">{{hide ? 'visibility' : 'visibility_off'}}</mat-icon>\n        </mat-form-field>\n  </p>\n  <button id=\"login-btn\" routerLink=\"../home\">Login</button>\n  <button id=\"google-btn\" type=\"button\" class=\"btn btn-block\" (click)=\"signInWithGoogle()\">\n    <i class=\"fa fa-google\" aria-hidden=\"true\"></i>\n       Login with Google\n  </button>\n</div>\n\n"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _node_modules_angularfire2_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/angularfire2/auth */ "./node_modules/angularfire2/auth/index.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(firebase_app__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginComponent = /** @class */ (function () {
    function LoginComponent(_firebaseAuth) {
        this._firebaseAuth = _firebaseAuth;
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].email]);
        this.hide = true;
        this.user = _firebaseAuth.authState;
    }
    LoginComponent.prototype.ngOnInit = function () {
    };
    LoginComponent.prototype.signInWithGoogle = function () {
        return this._firebaseAuth.auth.signInWithPopup(new firebase_app__WEBPACK_IMPORTED_MODULE_3__["auth"].GoogleAuthProvider());
    };
    LoginComponent.prototype.getErrorMessage = function () {
        return this.email.hasError('required') ? 'You must enter a value' :
            this.email.hasError('email') ? 'Not a valid email' :
                '';
    };
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        __metadata("design:paramtypes", [_node_modules_angularfire2_auth__WEBPACK_IMPORTED_MODULE_2__["AngularFireAuth"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/navigation/navigation.component.css":
/*!*****************************************************!*\
  !*** ./src/app/navigation/navigation.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".navbar {\n  height: 80px;\n  padding: 0px 0px;\n  margin: 0px;\n}\n\n#navbarNavAltMarkup {\n  margin-left: 8%;\n}\n\n.navbar-nav a {\n  padding: 5px;\n  letter-spacing: 0.1rem;\n  font-weight: 700;\n  font-size: 13px;\n  margin: 5%;\n  transition: padding-bottom 0.7s, border-bottom 0.2s;\n  -moz-transition: padding-bottom 0.7s, border-bottom 0.2s;\n  -webkit-transition: padding-bottom 0.7s, border-bottom 0.2s;\n}\n\n.navbar-nav a:hover {\n  padding-bottom: 5%;\n  border-bottom: 5px solid #1709FF;\n}\n\n#user-actions button {\n  margin: 5px;\n}\n\n#brand {\n  position: absolute;\n  left: 50%;\n  margin-left: -50px !important;  /* 50% of your logo width */\n  display: block;\n  font-size: 25px;\n  font-family: 'Montserrat', sans-serif;\n  font-weight: 700;\n  transition: background 0.5s, padding-bottom 0.5s, font-size 0.5s;\n}\n\n#brand:hover {\n  padding-bottom: 1%;\n  font-size: 28px;\n  background: -webkit-linear-gradient(#1709ff, #333);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n\n#sign-in-btn {\n  height: 80px;\n  font-size: 13px;\n  padding: 10px 10px;\n  width: 120px;\n  background-color: inherit;\n  border: none;\n  transition: padding-bottom 0.2s;\n  -moz-transition: padding-bottom 0.2s;\n  -webkit-transition: padding-bottom 0.2s;\n}\n\n#sign-in-btn:hover {\n  cursor: pointer;\n  padding-bottom: 10%;\n}\n\n#sign-up-btn {\n  background-color: rgb(36, 36, 36);\n  color: white;\n  border: none;\n  font-weight: 800;\n  font-size: 13px;\n  padding: 10px 10px;\n  width: 150px;\n  transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -webkit-transition: background-color 0.8s, border 1.0s, color 0.4s;\n  -moz-transition: background-color 0.8s, border 1.0s, color 0.4s;\n}\n\n#sign-up-btn:hover {\n  cursor: pointer;\n  background-color: inherit;\n  border: 3px solid rgb(36, 36, 36);\n  color: rgb(36, 36, 36);\n}\n"

/***/ }),

/***/ "./src/app/navigation/navigation.component.html":
/*!******************************************************!*\
  !*** ./src/app/navigation/navigation.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar fixed-top\n        navbar-expand-lg\n        navbar-light\" style=\"background-color: white;\" id=\"main-nav\">\n  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNavAltMarkup\" aria-controls=\"navbarNavAltMarkup\"\n    aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n    <span class=\"navbar-toggler-icon\"></span>\n  </button>\n  <a id=\"brand\" class=\"navbar-brand\" href=\"#\">\n    MyPc\n    <span style=\"color: #1709FF\">.</span>\n  </a>\n  <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\n    <div class=\"navbar-nav justify-content-center\">\n      <a class=\"nav-item nav-link active\" href=\"#\">Home\n        <span class=\"sr-only\">(current)</span>\n      </a>\n      <a class=\"nav-item nav-link\" routerLink=\"installation\">Installation</a>\n      <a class=\"nav-item nav-link\" href=\"#\">Pricing</a>\n      <a class=\"nav-item nav-link\" href=\"#\">FAQ</a>\n    </div>\n  </div>\n  <div class=\"navbar-nav justify-content-right\" id=\"user-actions\">\n    <button id=\"sign-in-btn\" routerLink=\"../login\">Sign in</button>\n    <button id=\"sign-up-btn\" routerLink=\"../signup\">GET STARTED</button>\n  </div>\n</nav>\n\n<!--  DROP DOWN\n   <li class=\"nav-item dropdown\" ngbDropdown>\n    <a class=\"nav-link dropdown-toggle\" id=\"dropdown01\" ngbDropdownToggle>Category</a>\n    <div class=\"dropdown-menu\" aria-labelledby=\"dropdown01\" ngbDropdownMenu>\n      <a class=\"dropdown-item\" href=\"#\">Angular</a>\n      <a class=\"dropdown-item\" href=\"#\">React</a>\n      <a class=\"dropdown-item\" href=\"#\">Vue.js</a>\n    </div>\n  </li>\n-->\n"

/***/ }),

/***/ "./src/app/navigation/navigation.component.ts":
/*!****************************************************!*\
  !*** ./src/app/navigation/navigation.component.ts ***!
  \****************************************************/
/*! exports provided: NavigationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavigationComponent", function() { return NavigationComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var NavigationComponent = /** @class */ (function () {
    function NavigationComponent() {
        this.user = {
            name: 'Elan',
            email: 'elfraiman@gmail.com'
        };
        this.userConnected = true;
    }
    NavigationComponent.prototype.ngOnInit = function () {
    };
    NavigationComponent.prototype.disconnectUser = function () {
        this.userConnected = false;
    };
    NavigationComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-navigation',
            template: __webpack_require__(/*! ./navigation.component.html */ "./src/app/navigation/navigation.component.html"),
            styles: [__webpack_require__(/*! ./navigation.component.css */ "./src/app/navigation/navigation.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], NavigationComponent);
    return NavigationComponent;
}());



/***/ }),

/***/ "./src/app/services/auth.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! angularfire2/auth */ "./node_modules/angularfire2/auth/index.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(firebase_app__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/@angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AuthService = /** @class */ (function () {
    function AuthService(_firebaseAuth, router) {
        var _this = this;
        this._firebaseAuth = _firebaseAuth;
        this.router = router;
        this.userDetails = null;
        this.user = _firebaseAuth.authState;
        this.user.subscribe(function (user) {
            if (user) {
                _this.userDetails = user;
                console.log(_this.userDetails);
            }
            else {
                _this.userDetails = null;
            }
        });
    }
    AuthService.prototype.signInWithGoogle = function () {
        return this._firebaseAuth.auth.signInWithPopup(new firebase_app__WEBPACK_IMPORTED_MODULE_2__["auth"].GoogleAuthProvider());
    };
    AuthService.prototype.isLoggedIn = function () {
        if (this.userDetails == null) {
            return false;
        }
        else {
            return true;
        }
    };
    AuthService.prototype.logout = function () {
        var _this = this;
        this._firebaseAuth.auth.signOut()
            .then(function (res) { return _this.router.navigate(['/']); });
    };
    AuthService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [angularfire2_auth__WEBPACK_IMPORTED_MODULE_1__["AngularFireAuth"], _node_modules_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/signup/signup.component.css":
/*!*********************************************!*\
  !*** ./src/app/signup/signup.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-content {\n  display: -ms-grid;\n  display: grid;\n  -ms-grid-rows: auto;\n  -ms-grid-columns: auto;\n      grid-template: auto/auto;\n  margin-top: 10%;\n  font-family: 'Montserrat', sans-serif;\n}\nh4 {\n  -ms-grid-row: 1;\n  -ms-grid-row-span: 1;\n  grid-row: 1/2;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  font-family: 'Ubuntu', sans-serif;\n}\n.email {\n  -ms-grid-row: 2;\n  -ms-grid-row-span: 1;\n  grid-row: 2/3;\n  -ms-grid-column-align: center;\n      justify-self: center;\n}\n.password {\n  -ms-grid-row: 4;\n  -ms-grid-row-span: 1;\n  grid-row: 4/5;\n  -ms-grid-column-align: center;\n      justify-self: center;\n}\n#sign-up-btn {\n  -ms-grid-row: 5;\n  -ms-grid-row-span: 1;\n  grid-row: 5/6;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  background-color: rgb(36, 36, 36);\n  color: white;\n  border: none;\n  font-weight: 800;\n  font-size: 13px;\n  padding: 8px 8px;\n  width: 120px;\n  height: 40px;\n  transition: background-color 0.6s, border 1.0s, color 0.4s;\n  -webkit-transition: background-color 0.6s, border 1.0s, color 0.4s;\n  -moz-transition: background-color 0.6s, border 1.0s, color 0.4s;\n}\n#sign-up-btn:hover {\ncursor: pointer;\nbackground-color: white;\nborder: 2px solid rgb(36, 36, 36);\ncolor: rgb(36, 36, 36);\n}\n#sign-in-btn {\n  -ms-grid-row: 6;\n  -ms-grid-row-span: 1;\n  grid-row: 6/7;\n  -ms-grid-column-align: center;\n      justify-self: center;\n  height: 80px;\n  font-size: 13px;\n  padding: 10px 10px;\n  width: 120px;\n  background-color: inherit;\n  border: none;\n  transition: paddingtop 0.2s, font-size 0.2s;\n  -moz-transition: paddingtop 0.2s, font-size 0.2s;\n  -webkit-transition: padding-top 0.2s, font-size 0.2s;\n}\n#sign-in-btn:hover {\n  cursor: pointer;\n  padding-top: 2%;\n  font-size: 17px\n}\n"

/***/ }),

/***/ "./src/app/signup/signup.component.html":
/*!**********************************************!*\
  !*** ./src/app/signup/signup.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-navigation></app-navigation>\n<div class=\"main-content\">\n  <h4>Signup to use our service</h4>\n  <p class=\"email\">\n      <mat-form-field appearance=\"outline\">\n          <mat-label>Email</mat-label>\n          <input matInput placeholder=\"Enter your email\" [formControl]=\"email\" required>\n          <mat-error *ngIf=\"email.invalid\">{{getErrorMessage()}}</mat-error>\n          <mat-icon matSuffix>sentiment_very_satisfied</mat-icon>\n        </mat-form-field>\n  </p>\n  <p class=\"password\">\n      <mat-form-field appearance=\"outline\">\n          <mat-label>Password</mat-label>\n          <input matInput placeholder=\"Enter your password\" [type]=\"hide ? 'password' : 'text'\">\n          <mat-icon matSuffix (click)=\"hide = !hide\">{{hide ? 'visibility' : 'visibility_off'}}</mat-icon>\n        </mat-form-field>\n  </p>\n  <button routerLink=\"../home\" id=\"sign-up-btn\">Signup</button>\n  <button id=\"sign-in-btn\" routerLink=\"../login\">Or Sign in</button>\n</div>\n\n"

/***/ }),

/***/ "./src/app/signup/signup.component.ts":
/*!********************************************!*\
  !*** ./src/app/signup/signup.component.ts ***!
  \********************************************/
/*! exports provided: SignupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupComponent", function() { return SignupComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SignupComponent = /** @class */ (function () {
    function SignupComponent() {
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].email]);
        this.hide = true;
    }
    SignupComponent.prototype.ngOnInit = function () {
    };
    SignupComponent.prototype.getErrorMessage = function () {
        return this.email.hasError('required') ? 'You must enter a value' :
            this.email.hasError('email') ? 'Not a valid email' :
                '';
    };
    SignupComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-signup',
            template: __webpack_require__(/*! ./signup.component.html */ "./src/app/signup/signup.component.html"),
            styles: [__webpack_require__(/*! ./signup.component.css */ "./src/app/signup/signup.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], SignupComponent);
    return SignupComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    firebase: {
        apiKey: 'AIzaSyAzT97ptmfba-T7Av2zT2wmTczWnQjLBvg',
        authDomain: 'mypc-5731c.firebaseapp.com',
        databaseURL: 'https://mypc-5731c.firebaseio.com',
        projectId: 'mypc-5731c',
        storageBucket: '',
        messagingSenderId: '864832263828'
    }
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/elan/Documents/code/yoni-project/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map